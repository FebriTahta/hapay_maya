<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <!-- Card -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">DataTable with default features</h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-lg">
                            Tambah Data
                        </button>
                        <br></br>
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>NO</th>
                                    <th>WILAYAH</th>
                                    <th>BULAN</th>
                                    <th>NAMA CLIENT</th>
                                    <th>ALAMAT CLIENT</th>
                                    <th>CLIENT ID</th>
                                    <th>APP ID</th>
                                    <th>NO SIMF</th>
                                    <th>ID INVOICE</th>
                                    <th>NO SPP</th>
                                    <th>SERVICE</th>
                                    <th>TERBIT SPP</th>
                                    <th>BATAS BAYAR</th>
                                    <th>AWAL PERIODE BHP</th>
                                    <th>POTENSI BHP</th>
                                    <th>BESAR BHP</th>
                                    <th>TAHUN PERIODE</th>
                                    <th>STATUS BAYAR</th>
                                    <th>STATUS ISR</th>
                                    <th>TGL PEMBAYARAN</th>
                                    <th>BHP TERBAYAR</th>
                                    <th>BHP DIBATALKAN</th>
                                    <th>DENDA TUNGGAKAN</th>
                                    <th>KETERANGAN</th>
                                    <th>ID INVOICE SURAT</th>
                                    <th>NO TAGIHAN</th>
                                    <th>TERBIT SURAT</th>
                                    <th>BATAS BAYAR SURAT</th>
                                    <th>TAGIHAN</th>
                                    <th>STATUS BAYAR SURAT</th>
                                    <th>ACTION</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                include '../conf/config.php';
                                $no = 1;
                                $data = mysqli_query($koneksi, "SELECT * FROM db_client"); 
                                while ($d = mysqli_fetch_array($data)) {
                                ?>
                                    <tr>
                                        <td><?php echo $no++; ?></td>
                                        <td><?php echo htmlspecialchars($d['wilayah']); ?></td>
                                        <td><?php echo htmlspecialchars($d['bulan']); ?></td>
                                        <td><?php echo htmlspecialchars($d['nama_client']); ?></td>
                                        <td><?php echo htmlspecialchars($d['alamat_client']); ?></td>
                                        <td><?php echo htmlspecialchars($d['client_id']); ?></td>
                                        <td><?php echo htmlspecialchars($d['app_id']); ?></td>
                                        <td><?php echo htmlspecialchars($d['no_simf']); ?></td>
                                        <td><?php echo htmlspecialchars($d['id_invoice']); ?></td>
                                        <td><?php echo htmlspecialchars($d['no_spp']); ?></td>
                                        <td><?php echo htmlspecialchars($d['service']); ?></td>
                                        <td><?php echo htmlspecialchars($d['terbit_spp']); ?></td>
                                        <td><?php echo htmlspecialchars($d['batas_bayar']); ?></td>
                                        <td><?php echo htmlspecialchars($d['awal_periode_bhp']); ?></td> 
                                        <!-- Format angka dengan number_format() -->
                                        <td><?php echo "Rp " . number_format($d['potensi_bhp'], 0, ',', '.'); ?></td>
                                        <td><?php echo "Rp " . number_format($d['besar_bhp'], 0, ',', '.'); ?></td>
                                        <td><?php echo htmlspecialchars($d['tahun_periode']); ?></td>
                                        <td><?php echo htmlspecialchars($d['status_bayar']); ?></td>
                                        <td><?php echo htmlspecialchars($d['status_isr']); ?></td>
                                        <td><?php echo htmlspecialchars($d['tgl_pembayaran']); ?></td>
                                        <!-- Format angka dengan number_format() -->
                                        <td><?php echo "Rp " . number_format($d['bhp_terbayar'], 0, ',', '.'); ?></td>
                                        <td><?php echo "Rp " . number_format($d['bhp_dibatalkan'], 0, ',', '.'); ?></td>
                                        <td><?php echo "Rp " . number_format($d['denda_tunggakan'], 0, ',', '.'); ?></td>
                                        <td><?php echo htmlspecialchars($d['keterangan']); ?></td>
                                        <td><?php echo htmlspecialchars($d['id_invoice_surat']); ?></td>
                                        <td><?php echo htmlspecialchars($d['no_tagihan']); ?></td>
                                        <td><?php echo htmlspecialchars($d['terbit_surat']); ?></td>
                                        <td><?php echo htmlspecialchars($d['batas_bayar_surat']); ?></td>   
                                        <!-- Format angka dengan number_format() -->
                                        <td><?php echo "Rp " . number_format($d['tagihan'], 0, ',', '.'); ?></td>
                                        <td><?php echo htmlspecialchars($d['status_bayar_surat']); ?></td>
                                        <td>
                                        <!-- Tombol View -->
                                        <a href="view.php?id=<?php echo $d['id']; ?>" class="btn btn-primary btn-sm">
                                            <i class="fas fa-eye"></i> View
                                        </a>

                                        <!-- Tombol Edit -->
                                        <a href="edit.php?id=<?php echo $d['id']; ?>" class="btn btn-warning btn-sm">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>

                                        <!-- Tombol Delete dengan Konfirmasi -->
                                        <a href="delete.php?id=<?php echo $d['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?');">
                                            <i class="fas fa-trash"></i> Delete
                                        </a>
                                    </td>

                                    </tr>
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>

<div class="modal fade" id="modal-lg">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Data Client</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Form Tambah Data -->
                <form action="add/tambah_data.php" method="POST">
                    
                    <!-- Wilayah -->
                    <label for="wilayah">Wilayah:</label>
                    <input type="text" name="wilayah" id="wilayah" class="form-control" required>

                    <!-- Bulan -->
                    <label for="bulan">Bulan:</label>
                    <input type="number" name="bulan" id="bulan" class="form-control" required>

                    <!-- No -->
                    <label for="no">No:</label>
                    <input type="number" name="no" id="no" class="form-control" required>

                    <!-- Nama Client -->
                    <label for="nama_client">Nama Client:</label>
                    <select name="nama_client" id="nama_client" class="form-control select2">
                    <option value="">-- Pilih Nama Client --</option>
                    <option value="tambah_baru">+ Tambah Client Baru</option>
                    <?php
                    // Koneksi ke database
                    $conn = new mysqli("localhost", "root", "", "db_hapay");

                    // Cek koneksi
                    if ($conn->connect_error) {
                        die("Koneksi gagal: " . $conn->connect_error);
                    }

                    // Ambil data client_id dan nama_client dari tabel db_client
                    $sql = "SELECT client_id, nama_client FROM db_client";
                    $result = $conn->query($sql);

                    // Loop data untuk membuat opsi dropdown
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row['client_id'] . "'>" . $row['nama_client'] . "</option>";
                    }

                    // Tutup koneksi
                    $conn->close();
                    ?>
                </select>

                    <!-- Form Tambah Client Baru (Tersembunyi) -->
                    <div id="form_client_baru" style="display: none;">
                        <label for="nama_client_baru">Nama Client Baru:</label>
                        <input type="text" name="nama_client_baru" id="nama_client_baru" class="form-control">
                    </div>

                    <!-- Script untuk Menampilkan Form Client Baru -->
                    <script>
                    document.getElementById("nama_client").addEventListener("change", function() {
                        var formClientBaru = document.getElementById("form_client_baru");
                        if (this.value === "tambah_baru") {
                            formClientBaru.style.display = "block";
                        } else {
                            formClientBaru.style.display = "none";
                            document.getElementById("nama_client_baru").value = "";
                            document.getElementById("alamat_client_baru").value = "";
                        }
                    });
                    </script>

                    <!-- Alamat Client -->
                    <label for="alamat_client">Alamat Client:</label>
                    <textarea name="alamat_client" id="alamat_client" class="form-control"></textarea>

                    <!-- Client ID -->
                    <label for="client_id">Client ID:</label>
                    <input type="number" name="client_id" id="client_id" class="form-control">

                    <!-- App ID -->
                    <label for="app_id">App ID:</label>
                    <input type="number" name="app_id" id="app_id" class="form-control">

                    <!-- No Simf -->
                    <label for="no_simf">No Simf:</label>
                    <input type="number" name="no_simf" id="no_simf" class="form-control">

                    <!-- ID Invoice -->
                    <label for="id_invoice">ID Invoice:</label>
                    <input type="number" name="id_invoice" id="id_invoice" class="form-control">

                    <!-- No SPP -->
                    <label for="no_spp">No SPP:</label>
                    <input type="number" name="no_spp" id="no_spp" class="form-control">

                    <!-- Service -->
                    <label for="service">Service:</label>
                    <input type="text" name="service" id="service" class="form-control">

                    <!-- Tanggal Terbit SPP -->
                    <label for="terbit_spp">Terbit SPP:</label>
                    <input type="date" name="terbit_spp" id="terbit_spp" class="form-control">

                    <!-- Batas Bayar -->
                    <label for="batas_bayar">Batas Bayar:</label>
                    <input type="date" name="batas_bayar" id="batas_bayar" class="form-control">

                    <!-- Awal Periode BHP -->
                    <label for="awal_periode_bhp">Awal Periode BHP:</label>
                    <input type="date" name="awal_periode_bhp" id="awal_periode_bhp" class="form-control">

                    <!-- Potensi BHP -->
                    <label for="potensi_bhp">Potensi BHP:</label>
                    <input type="number" step="0.01" name="potensi_bhp" id="potensi_bhp" class="form-control">

                    <!-- Besar BHP -->
                    <label for="besar_bhp">Besar BHP:</label>
                    <input type="number" step="0.01" name="besar_bhp" id="besar_bhp" class="form-control">

                    <!-- Tahun Periode -->
                    <label for="tahun_periode">Tahun Periode:</label>
                    <input type="number" name="tahun_periode" id="tahun_periode" class="form-control">

                    <!-- Status Bayar -->
                    <label for="status_bayar">Status Bayar:</label>
                    <input type="text" name="status_bayar" id="status_bayar" class="form-control">

                    <!-- Status ISR -->
                    <label for="status_isr">Status ISR:</label>
                    <input type="text" name="status_isr" id="status_isr" class="form-control">

                    <!-- Tanggal Pembayaran -->
                    <label for="tgl_pembayaran">Tanggal Pembayaran:</label>
                    <input type="date" name="tgl_pembayaran" id="tgl_pembayaran" class="form-control">

                    <!-- BHP Terbayar -->
                    <label for="bhp_terbayar">BHP terbayar:</label>
                    <input type="number" name="bhp_terbayar" id="bhp_terbayar" class="form-control">

                    <!-- BHP Dibatalkan -->
                    <label for="bhp_dibatalkan">BHP Dibatalkan:</label>
                    <input type="number" name="bhp_dibatalkan" id="bhp_dibatalkan" class="form-control">

                    <!-- Denda Tunggakan -->
                    <label for="denda_tunggakan">BHP Ditunggakan:</label>
                    <input type="number" name="denda_tunggakan" id="denda_tunggakan" class="form-control">

                    <!-- Keterangan -->
                    <label for="keterangan">Keterangan:</label>
                    <textarea name="keterangan" id="keterangan" class="form-control"></textarea>

                    <!-- ID Invoice Surat -->
                    <label for="id_invoice_surat">ID Invoice Surat:</label>
                    <input type="number" name="id_invoice_surat" id="id_invoice_surat" class="form-control">

                    <!-- No Tagihan -->
                    <label for="no_tagihan">No Tagihan:</label>
                    <input type="number" name="no_tagihan" id="no_tagihan" class="form-control">

                    <!-- Terbit Surat -->
                    <label for="terbit_surat"> Terbit Surat:</label>
                    <input type="number" name="terbit_surat" id="terbit_surat" class="form-control">

                    <!-- Batas Bayar Surat -->
                    <label for="batas_bayar_surat">Batas Bayar Surat:</label>
                    <input type="date" name="batas_bayar_surat" id="batas_bayar_surat" class="form-control">

                    <!-- Tagihan -->
                    <label for="tagihan"> Tagihan:</label>
                    <input type="number" name="tagihan" id="tagihan" class="form-control">

                    <!-- Status ISR -->
                    <label for="status_bayar_surat">Status Bayar Surat:</label>
                    <input type="text" name="status_bayar_surat" id="status_bayar_surat" class="form-control">

                    <!-- Tombol Submit -->
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form> <!-- Pastikan form ditutup di sini -->
            </div> <!-- modal-body -->
        </div> <!-- modal-content -->
    </div> <!-- modal-dialog -->
</div> <!-- modal -->

