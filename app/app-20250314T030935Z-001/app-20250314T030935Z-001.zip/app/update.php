update.php
<?php
include '../conf/config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Tangkap semua data dari form
    $wilayah = $_POST['wilayah'];
    $bulan = $_POST['bulan'];
    $no = $_POST['no'];
    $nama_client = $_POST['nama_client'];
    $alamat_client = $_POST['alamat_client'];
    $client_id = $_POST['client_id'];
    $app_id = $_POST['app_id'];
    $no_simf = $_POST['no_simf'];
    $id_invoice = $_POST['id_invoice'];
    $no_spp = $_POST['no_spp'];
    $service = $_POST['service'];
    $terbit_spp = $_POST['terbit_spp'];
    $batas_bayar = $_POST['batas_bayar'];
    $awal_periode_bhp = $_POST['awal_periode_bhp'];
    $potensi_bhp = $_POST['potensi_bhp'];
    $besar_bhp = $_POST['besar_bhp'];
    $tahun_periode = $_POST['tahun_periode'];
    $status_bayar = $_POST['status_bayar'];
    $status_isr = $_POST['status_isr'];
    $tgl_pembayaran = $_POST['tgl_pembayaran'];
    $bhp_terbayar = $_POST['bhp_terbayar'];
    $bhp_dibatalkan = $_POST['bhp_dibatalkan'];
    $denda_tunggakan = $_POST['denda_tunggakan'];
    $keterangan = $_POST['keterangan'];
    $id_invoice_surat = $_POST['id_invoice_surat'];
    $no_tagihan = $_POST['no_tagihan'];
    $terbit_surat = $_POST['terbit_surat'];
    $batas_bayar_surat = $_POST['batas_bayar_surat'];
    $tagihan = $_POST['tagihan'];
    $status_bayar_surat = $_POST['status_bayar_surat'];

    // Pastikan ada ID client untuk update
    if (empty($client_id)) {
        die("Error: ID client tidak ditemukan.");
    }

    // Query Update yang lebih lengkap
    $query = "UPDATE db_client SET 
        wilayah = '$wilayah',
        bulan = '$bulan',
        no = '$no',
        nama_client = '$nama_client',
        alamat_client = '$alamat_client',
        app_id = '$app_id',
        no_simf = '$no_simf',
        id_invoice = '$id_invoice',
        no_spp = '$no_spp',
        service = '$service',
        terbit_spp = '$terbit_spp',
        batas_bayar = '$batas_bayar',
        awal_periode_bhp = '$awal_periode_bhp',
        potensi_bhp = '$potensi_bhp',
        besar_bhp = '$besar_bhp',
        tahun_periode = '$tahun_periode',
        status_bayar = '$status_bayar',
        status_isr = '$status_isr',
        tgl_pembayaran = '$tgl_pembayaran',
        bhp_terbayar = '$bhp_terbayar',
        bhp_dibatalkan = '$bhp_dibatalkan',
        denda_tunggakan = '$denda_tunggakan',
        keterangan = '$keterangan',
        id_invoice_surat = '$id_invoice_surat',
        no_tagihan = '$no_tagihan',
        terbit_surat = '$terbit_surat',
        batas_bayar_surat = '$batas_bayar_surat',
        tagihan = '$tagihan',
        status_bayar_surat = '$status_bayar_surat'
        WHERE client_id = '$client_id'";

    // Eksekusi query
    $result = mysqli_query($koneksi, $query);

    if ($result) {
        // Redirect jika berhasil
        header("location:index.php?page=data&status=success");
    } else {
        // Tampilkan error jika gagal
        echo "Error: " . mysqli_error($koneksi);
    }
} else {
    // Jika tidak ada request POST, redirect kembali
    header("location:index.php?page=data");
}
?>